<footer class="site-footer">

<nav class="site-nav">
        <?php 
            $args = array('theme_location' => 'seconds');
        ?>
        <?php wp_nav_menu($args); ?>
</nav>
<p><?php bloginfo('Mawuzole Marvin Zuma'); ?> - &copy; <?php echo date('2019'); ?></p>
<?php wp_footer(); ?>


</footer>
</body>
</html>